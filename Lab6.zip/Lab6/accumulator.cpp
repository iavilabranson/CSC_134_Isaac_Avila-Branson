//@author: Isaac Avila-Branson
//@date: 09/24/2025
//@purpose: Create a program to count number of iterations in a for-loop

#include <iostream>
using namespace std;

int main() { 
    int accumulator; //create integer for accumulator
    for (accumulator = 0; accumulator < 100; accumulator++) {
        //empty for loop for iterating
    }
    cout << "The Accumulator value is: " << accumulator << endl; //print final value
    return 0;

}